from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils import executor
import logging

import os
API_TOKEN = os.getenv('API_TOKEN')

# Включаем логирование
logging.basicConfig(level=logging.INFO)

# Инициализация бота и диспетчера
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# Пример рецептов
recipes = [
    {"name": "Овсянка с фруктами", "calories": 320, "b": 8, "j": 5, "u": 55, "type": "завтрак"},
    {"name": "Куриная грудка с овощами", "calories": 400, "b": 35, "j": 10, "u": 20, "type": "обед"},
    {"name": "Салат с тунцом", "calories": 280, "b": 22, "j": 12, "u": 10, "type": "ужин"},
    {"name": "Паста с томатами", "calories": 450, "b": 12, "j": 15, "u": 60, "type": "обед"},
    {"name": "Омлет с сыром и зеленью", "calories": 350, "b": 20, "j": 25, "u": 5, "type": "завтрак"},
    {"name": "Йогуртовый десерт с ягодами", "calories": 250, "b": 10, "j": 8, "u": 35, "type": "десерт"},
]

# Хранилище пользовательских данных
user_goals = {}

# Главное меню
main_kb = ReplyKeyboardMarkup(resize_keyboard=True)
main_kb.add(KeyboardButton("🍽 Поиск по предпочтениям"))
main_kb.add(KeyboardButton("🔥 Поиск по калориям"))
main_kb.add(KeyboardButton("📅 Рацион на день"))
main_kb.add(KeyboardButton("📊 Показать БЖУ"))
main_kb.add(KeyboardButton("🎯 Установить цель по калориям"))
main_kb.add(KeyboardButton("❌ Отменить"))

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.answer("Привет! Я бот \"Рецепты на каждый день\". Выбери, что ты хочешь:", reply_markup=main_kb)

@dp.message_handler(lambda message: message.text == "🍽 Поиск по предпочтениям")
async def search_by_preference(message: types.Message):
    types_set = set(recipe['type'] for recipe in recipes)
    result = "Выберите категорию:\n" + "\n".join(f"- {t}" for t in types_set)
    await message.answer(result)

@dp.message_handler(lambda message: message.text == "🔥 Поиск по калориям")
async def search_by_calories(message: types.Message):
    result = "Введите желаемое количество калорий (например: 400):"
    await message.answer(result)

@dp.message_handler(lambda message: message.text.isdigit())
async def show_by_calories(message: types.Message):
    cal = int(message.text)
    filtered = [r for r in recipes if r["calories"] <= cal]
    if not filtered:
        await message.answer("Нет блюд с такой калорийностью")
    else:
        msg = "Вот подходящие рецепты:\n" + "\n".join([f"{r['name']} – {r['calories']} ккал" for r in filtered])
        await message.answer(msg)

@dp.message_handler(lambda message: message.text == "📅 Рацион на день")
async def day_plan(message: types.Message):
    user_id = message.from_user.id
    goal = user_goals.get(user_id, 1800)
    total = 0
    plan = []
    for r in recipes:
        if total + r['calories'] <= goal:
            plan.append(r)
            total += r['calories']
    text = f"Рацион на день (цель: {goal} ккал):\n" + "\n".join([f"{r['name']} – {r['calories']} ккал" for r in plan]) + f"\nИтого: {total} ккал"
    await message.answer(text)

@dp.message_handler(lambda message: message.text == "📊 Показать БЖУ")
async def show_bju_info(message: types.Message):
    text = "БЖУ по рецептам:\n"
    for r in recipes:
        text += f"{r['name']}: Б {r['b']}г / Ж {r['j']}г / У {r['u']}г\n"
    await message.answer(text)

@dp.message_handler(lambda message: message.text == "🎯 Установить цель по калориям")
async def set_goal_prompt(message: types.Message):
    await message.answer("Введите вашу дневную цель по калориям (например: 2000):")

@dp.message_handler(lambda message: message.text.isdigit())
async def set_goal_value(message: types.Message):
    cal = int(message.text)
    if 1000 <= cal <= 4000:
        user_goals[message.from_user.id] = cal
        await message.answer(f"Цель установлена: {cal} ккал в день")
    else:
        await message.answer("Пожалуйста, введите значение от 1000 до 4000")

@dp.message_handler(lambda message: message.text == "❌ Отменить")
async def cancel_action(message: types.Message):
    await message.answer("Действие отменено. Возвращаюсь в главное меню.", reply_markup=main_kb)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
